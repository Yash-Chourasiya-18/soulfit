document.addEventListener('DOMContentLoaded', () => {
  const menuBtn = document.querySelector('.three-dot-btn');
  const header = document.querySelector('#mainHeader');

  if (menuBtn) {
    menuBtn.addEventListener('click', () => {
      // Toggle mobile menu logic could go here
      console.log('Menu clicked');
    });
  }

  // Header scroll effect
  window.addEventListener('scroll', () => {
    if (window.scrollY > 20) {
      header.classList.add('header-scrolled');
    } else {
      header.classList.remove('header-scrolled');
    }
  });
});
